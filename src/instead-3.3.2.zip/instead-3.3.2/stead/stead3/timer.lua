-- luacheck: globals timer
timer = stead.ref '@timer'

-- luacheck: globals sprite pixels
sprite = stead.ref '@sprite'
pixels = stead.ref '@pixels'
